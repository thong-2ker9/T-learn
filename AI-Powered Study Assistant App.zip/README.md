
  # AI-Powered Study Assistant App

  This is a code bundle for AI-Powered Study Assistant App. The original project is available at https://www.figma.com/design/UYNlna9ZMLAe38vgikH5sT/AI-Powered-Study-Assistant-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  