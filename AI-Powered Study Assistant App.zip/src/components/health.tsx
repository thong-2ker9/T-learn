import { useState } from "react";
import { ArrowLeft, Droplets, Dumbbell, Users, Brain, Settings, Play, Pause, RotateCcw } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Switch } from "./ui/switch";

interface HealthProps {
  onBack: () => void;
}

interface WaterSettings {
  enabled: boolean;
  interval: number; // minutes
  startTime: string;
  endTime: string;
}

interface ExerciseSettings {
  enabled: boolean;
  type: 'ai' | 'sport';
  duration: number; // minutes
  time: string;
  sport?: string;
  customSport?: string;
}

interface MeditationSession {
  id: string;
  name: string;
  duration: number;
  audioUrl?: string;
}

const predefinedSports = [
  "Bóng đá", "Bóng rổ", "Cầu lông", "Tennis", "Bơi lội", 
  "Chạy bộ", "Xe đạp", "Yoga", "Boxing", "Võ thuật"
];

const meditationSessions: MeditationSession[] = [
  { id: "1", name: "Hơi thở sâu", duration: 10 },
  { id: "2", name: "Thư giãn toàn thân", duration: 15 },
  { id: "3", name: "Thiền chánh niệm", duration: 20 },
  { id: "4", name: "Giảm stress", duration: 12 },
  { id: "5", name: "Tập trung tinh thần", duration: 18 },
];

export function Health({ onBack }: HealthProps) {
  const [waterSettings, setWaterSettings] = useState<WaterSettings>({
    enabled: false,
    interval: 180, // 3 hours
    startTime: "07:00",
    endTime: "22:00"
  });

  const [exerciseSettings, setExerciseSettings] = useState<ExerciseSettings>({
    enabled: false,
    type: 'ai',
    duration: 30,
    time: "18:00"
  });

  const [selectedMeditation, setSelectedMeditation] = useState<MeditationSession | null>(null);
  const [meditationTimer, setMeditationTimer] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [aiExercisePrompt, setAiExercisePrompt] = useState("");

  const handleWaterNotification = () => {
    if (waterSettings.enabled) {
      // In a real app, this would set up actual notifications
      alert(`Đã cài đặt nhắc nhở uống nước mỗi ${waterSettings.interval} phút từ ${waterSettings.startTime} đến ${waterSettings.endTime}`);
    }
  };

  const handleExerciseNotification = () => {
    if (exerciseSettings.enabled) {
      const message = exerciseSettings.type === 'ai' 
        ? `Đã cài đặt nhắc nhở tập thể dục với AI vào lúc ${exerciseSettings.time} trong ${exerciseSettings.duration} phút`
        : `Đã cài đặt nhắc nhở chơi ${exerciseSettings.sport || exerciseSettings.customSport} vào lúc ${exerciseSettings.time}`;
      alert(message);
    }
  };

  const generateAIExercise = () => {
    // Mock AI response
    const exercises = [
      "20 Squats + 15 Push-ups + 30 giây Plank",
      "Chạy tại chỗ 2 phút + 10 Burpees + Stretching",
      "15 Lunges mỗi chân + 20 Jumping Jacks + Yoga cơ bản",
      "Cardio nhẹ 5 phút + 15 Sit-ups + Thở sâu"
    ];
    
    const randomExercise = exercises[Math.floor(Math.random() * exercises.length)];
    setAiExercisePrompt(randomExercise);
  };

  const startMeditation = (session: MeditationSession) => {
    setSelectedMeditation(session);
    setMeditationTimer(session.duration * 60); // Convert to seconds
    setIsPlaying(true);
  };

  const toggleMeditation = () => {
    setIsPlaying(!isPlaying);
  };

  const resetMeditation = () => {
    setIsPlaying(false);
    setMeditationTimer(selectedMeditation ? selectedMeditation.duration * 60 : 0);
  };

  // Timer effect would go here in a real implementation
  // useEffect for countdown timer

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={onBack} className="mr-4">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-3xl font-bold text-green-600">Sức Khỏe</h1>
        </div>

        <Tabs defaultValue="water" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="water" className="flex items-center gap-2">
              <Droplets className="w-4 h-4" />
              Uống Nước
            </TabsTrigger>
            <TabsTrigger value="exercise" className="flex items-center gap-2">
              <Dumbbell className="w-4 h-4" />
              Tập Thể Dục
            </TabsTrigger>
            <TabsTrigger value="meditation" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Thiền - Thư Giãn
            </TabsTrigger>
          </TabsList>

          <TabsContent value="water">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Droplets className="w-5 h-5 text-blue-500" />
                Nhắc Nhở Uống Nước
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="water-enabled">Bật nhắc nhở</Label>
                  <Switch
                    id="water-enabled"
                    checked={waterSettings.enabled}
                    onCheckedChange={(checked) => 
                      setWaterSettings(prev => ({ ...prev, enabled: checked }))
                    }
                  />
                </div>

                {waterSettings.enabled && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="water-interval">Khoảng thời gian (phút)</Label>
                        <Input
                          id="water-interval"
                          type="number"
                          value={waterSettings.interval}
                          onChange={(e) => 
                            setWaterSettings(prev => ({ ...prev, interval: parseInt(e.target.value) || 180 }))
                          }
                          min="30"
                          max="480"
                        />
                      </div>
                      <div>
                        <Label>Thời gian hiệu lực</Label>
                        <div className="flex gap-2 items-center">
                          <Input
                            type="time"
                            value={waterSettings.startTime}
                            onChange={(e) => 
                              setWaterSettings(prev => ({ ...prev, startTime: e.target.value }))
                            }
                          />
                          <span>-</span>
                          <Input
                            type="time"
                            value={waterSettings.endTime}
                            onChange={(e) => 
                              setWaterSettings(prev => ({ ...prev, endTime: e.target.value }))
                            }
                          />
                        </div>
                      </div>
                    </div>

                    <Button onClick={handleWaterNotification} className="w-full bg-blue-500 hover:bg-blue-600">
                      Lưu Cài Đặt Nhắc Nhở
                    </Button>
                  </>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="exercise">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Dumbbell className="w-5 h-5 text-red-500" />
                Tập Thể Dục & Thể Thao
              </h2>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="exercise-enabled">Bật nhắc nhở</Label>
                  <Switch
                    id="exercise-enabled"
                    checked={exerciseSettings.enabled}
                    onCheckedChange={(checked) => 
                      setExerciseSettings(prev => ({ ...prev, enabled: checked }))
                    }
                  />
                </div>

                {exerciseSettings.enabled && (
                  <>
                    <div>
                      <Label>Loại hoạt động</Label>
                      <Select 
                        value={exerciseSettings.type} 
                        onValueChange={(value: 'ai' | 'sport') => 
                          setExerciseSettings(prev => ({ ...prev, type: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ai">Tập thể dục với AI</SelectItem>
                          <SelectItem value="sport">Chơi thể thao</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {exerciseSettings.type === 'ai' ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="exercise-duration">Thời gian (phút)</Label>
                            <Input
                              id="exercise-duration"
                              type="number"
                              value={exerciseSettings.duration}
                              onChange={(e) => 
                                setExerciseSettings(prev => ({ ...prev, duration: parseInt(e.target.value) || 30 }))
                              }
                              min="10"
                              max="120"
                            />
                          </div>
                          <div>
                            <Label htmlFor="exercise-time">Thời gian nhắc nhở</Label>
                            <Input
                              id="exercise-time"
                              type="time"
                              value={exerciseSettings.time}
                              onChange={(e) => 
                                setExerciseSettings(prev => ({ ...prev, time: e.target.value }))
                              }
                            />
                          </div>
                        </div>
                        
                        <Button onClick={generateAIExercise} variant="outline" className="w-full">
                          Tạo Bài Tập Ngẫu Nhiên
                        </Button>
                        
                        {aiExercisePrompt && (
                          <div className="p-4 bg-green-50 rounded-lg">
                            <h4 className="font-semibold text-green-700 mb-2">Bài tập được đề xuất:</h4>
                            <p className="text-green-600">{aiExercisePrompt}</p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <Label>Chọn môn thể thao</Label>
                          <Select 
                            value={exerciseSettings.sport} 
                            onValueChange={(value) => 
                              setExerciseSettings(prev => ({ ...prev, sport: value, customSport: undefined }))
                            }
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Chọn môn thể thao" />
                            </SelectTrigger>
                            <SelectContent>
                              {predefinedSports.map(sport => (
                                <SelectItem key={sport} value={sport}>{sport}</SelectItem>
                              ))}
                              <SelectItem value="custom">Tự nhập môn khác</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {exerciseSettings.sport === 'custom' && (
                          <div>
                            <Label htmlFor="custom-sport">Nhập môn thể thao</Label>
                            <Input
                              id="custom-sport"
                              value={exerciseSettings.customSport || ''}
                              onChange={(e) => 
                                setExerciseSettings(prev => ({ ...prev, customSport: e.target.value }))
                              }
                              placeholder="Ví dụ: Bóng chuyền, Leo núi..."
                            />
                          </div>
                        )}

                        <div>
                          <Label htmlFor="sport-time">Thời gian nhắc nhở</Label>
                          <Input
                            id="sport-time"
                            type="time"
                            value={exerciseSettings.time}
                            onChange={(e) => 
                              setExerciseSettings(prev => ({ ...prev, time: e.target.value }))
                            }
                          />
                        </div>
                      </div>
                    )}

                    <Button onClick={handleExerciseNotification} className="w-full bg-red-500 hover:bg-red-600">
                      Lưu Cài Đặt Nhắc Nhở
                    </Button>
                  </>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="meditation">
            <div className="space-y-6">
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-500" />
                  Thiền - Thư Giãn
                </h2>

                {!selectedMeditation ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {meditationSessions.map(session => (
                      <Card key={session.id} className="p-4 cursor-pointer hover:bg-purple-50" onClick={() => startMeditation(session)}>
                        <h3 className="font-semibold text-purple-700">{session.name}</h3>
                        <p className="text-sm text-gray-600">{session.duration} phút</p>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center space-y-6">
                    <h3 className="text-2xl font-semibold text-purple-700">{selectedMeditation.name}</h3>
                    
                    <div className="w-48 h-48 mx-auto bg-gradient-to-br from-purple-200 to-blue-200 rounded-full flex items-center justify-center">
                      <div className="text-4xl font-mono text-purple-700">
                        {formatTime(meditationTimer)}
                      </div>
                    </div>

                    <div className="flex justify-center gap-4">
                      <Button onClick={toggleMeditation} size="lg" className="bg-purple-500 hover:bg-purple-600">
                        {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                      </Button>
                      <Button onClick={resetMeditation} variant="outline" size="lg">
                        <RotateCcw className="w-5 h-5" />
                      </Button>
                      <Button onClick={() => setSelectedMeditation(null)} variant="outline" size="lg">
                        Thoát
                      </Button>
                    </div>

                    <div className="text-sm text-gray-600 max-w-md mx-auto">
                      <p>Hít vào sâu, thở ra chậm. Tập trung vào hơi thở và để tâm trí được thư giãn.</p>
                    </div>
                  </div>
                )}
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}