import { useState, useRef } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Upload, FileText, Video, Send, Download, Trash2, MessageCircle, BookOpen, Key } from "lucide-react";

interface Document {
  id: string;
  name: string;
  type: 'pdf' | 'video' | 'text';
  content: string;
  uploadDate: Date;
  processed: boolean;
  summary?: string;
  notes?: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  documentId?: string;
}

interface StudyAssistantProps {
  onBack: () => void;
}

export function StudyAssistant({ onBack }: StudyAssistantProps) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [activeDocument, setActiveDocument] = useState<Document | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load data from localStorage
  useState(() => {
    const savedDocs = localStorage.getItem('studyDocuments');
    if (savedDocs) {
      const parsed = JSON.parse(savedDocs).map((doc: any) => ({
        ...doc,
        uploadDate: new Date(doc.uploadDate)
      }));
      setDocuments(parsed);
    }

    const savedMessages = localStorage.getItem('studyChatMessages');
    if (savedMessages) {
      const parsed = JSON.parse(savedMessages).map((msg: any) => ({
        ...msg,
        timestamp: new Date(msg.timestamp)
      }));
      setChatMessages(parsed);
    }

    const savedApiKey = localStorage.getItem('studyAssistantApiKey');
    if (savedApiKey) {
      setApiKey(savedApiKey);
    }
  });

  // Save data to localStorage
  const saveDocuments = (newDocs: Document[]) => {
    setDocuments(newDocs);
    localStorage.setItem('studyDocuments', JSON.stringify(newDocs));
  };

  const saveChatMessages = (newMessages: ChatMessage[]) => {
    setChatMessages(newMessages);
    localStorage.setItem('studyChatMessages', JSON.stringify(newMessages));
  };

  const saveApiKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem('studyAssistantApiKey', key);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 50 * 1024 * 1024) { // 50MB limit
      alert('File quá lớn! Vui lòng chọn file nhỏ hơn 50MB.');
      return;
    }

    let fileType: 'pdf' | 'video' | 'text' = 'text';
    
    if (file.type.includes('pdf')) {
      fileType = 'pdf';
    } else if (file.type.includes('video')) {
      fileType = 'video';
    } else if (file.type.includes('text') || file.name.endsWith('.txt') || file.name.endsWith('.md')) {
      fileType = 'text';
    } else {
      alert('Loại file không được hỗ trợ! Vui lòng chọn PDF, video hoặc file text.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      
      const newDoc: Document = {
        id: Date.now().toString(),
        name: file.name,
        type: fileType,
        content,
        uploadDate: new Date(),
        processed: false
      };

      const newDocs = [newDoc, ...documents];
      saveDocuments(newDocs);
      
      // Auto process the document
      processDocument(newDoc);
    };

    if (fileType === 'text') {
      reader.readAsText(file);
    } else {
      reader.readAsDataURL(file);
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const processDocument = async (doc: Document) => {

    setIsProcessing(true);

    try {
      // Mock API call - thay thế bằng API thực tế
      await new Promise(resolve => setTimeout(resolve, 3000));

      const mockSummary = generateMockSummary(doc);
      const mockNotes = generateMockNotes(doc);

      const updatedDoc = {
        ...doc,
        processed: true,
        summary: mockSummary,
        notes: mockNotes
      };

      const updatedDocs = documents.map(d => 
        d.id === doc.id ? updatedDoc : d
      );
      
      saveDocuments(updatedDocs);
      
      if (activeDocument?.id === doc.id) {
        setActiveDocument(updatedDoc);
      }

    } catch (error) {
      alert('Có lỗi xảy ra khi xử lý tài liệu. Vui lòng thử lại.');
    } finally {
      setIsProcessing(false);
    }
  };

  const generateMockSummary = (doc: Document) => {
    const summaries = {
      pdf: `**Tóm tắt tài liệu PDF: ${doc.name}**

📋 **Nội dung chính:**
• Chương 1: Khái niệm cơ bản và định nghĩa
• Chương 2: Phương pháp và cách tiếp cận
• Chương 3: Ví dụ thực tế và bài tập

🎯 **Điểm quan trọng:**
• Công thức và định lý chính
• Các bước giải quyết vấn đề
• Lưu ý và mẹo học tập

📊 **Thống kê:**
• Số trang: ~25-30 trang
• Độ khó: Trung bình
• Thời gian học: 2-3 giờ`,

      video: `**Tóm tắt video bài giảng: ${doc.name}**

🎥 **Thông tin video:**
• Thời lượng: ~45-60 phút
• Chủ đề: Bài giảng chuyên sâu
• Người giảng: Giảng viên chuyên môn

📚 **Nội dung chính:**
• Phần 1 (0-15p): Giới thiệu và khái niệm
• Phần 2 (15-35p): Lý thuyết và phương pháp
• Phần 3 (35-45p): Bài tập và ví dụ thực tế

💡 **Kiến thức trọng tâm:**
• Định nghĩa và công thức cốt lõi
• Cách áp dụng vào bài tập
• Mẹo nhớ và tránh sai lầm`,

      text: `**Tóm tắt ghi chú: ${doc.name}**

📝 **Nội dung tài liệu:**
• Ghi chú lý thuyết chi tiết
• Các khái niệm và định nghĩa
• Ví dụ minh họa cụ thể

🔍 **Phân tích:**
• Cấu trúc rõ ràng, dễ hiểu
• Bao gồm các điểm quan trọng
• Có ví dụ thực tế hỗ trợ

📖 **Gợi ý học tập:**
• Đọc theo thứ tự từ đầu đến cuối
• Ghi chú các điểm chính
• Làm bài tập để củng cố kiến thức`
    };

    return summaries[doc.type];
  };

  const generateMockNotes = (doc: Document) => {
    return `**Ghi chú học tập cho: ${doc.name}**

🎯 **Mục tiêu học tập:**
- Nắm vững các khái niệm cơ bản
- Áp dụng được vào bài tập thực tế
- Hiểu sâu về nguyên lý và phương pháp

📋 **Checklist học tập:**
- [ ] Đọc/xem tài liệu lần đầu
- [ ] Ghi chú các điểm quan trọng
- [ ] Làm bài tập thực hành
- [ ] Ôn tập và củng cố kiến thức

💡 **Ghi chú quan trọng:**
- Chú ý các công thức và định lý
- Lưu ý cách giải bài tập từng bước
- Ghi nhớ các mẹo và lưu ý đặc biệt

🔄 **Kế hoạch ôn tập:**
- Tuần 1: Học lý thuyết cơ bản
- Tuần 2: Thực hành bài tập
- Tuần 3: Ôn tập tổng hợp`;
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !activeDocument) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date(),
      documentId: activeDocument.id
    };

    const newMessages = [...chatMessages, userMessage];
    saveChatMessages(newMessages);
    setInputMessage("");
    setIsChatLoading(true);

    try {
      // Mock API response
      await new Promise(resolve => setTimeout(resolve, 2000));

      const responses = [
        `Dựa trên tài liệu "${activeDocument.name}", tôi có thể giải thích rằng: ${inputMessage.toLowerCase().includes('là gì') ? 'đây là một khái niệm quan trọng được đề cập trong tài liệu' : 'điều này được giải thích chi tiết trong phần tương ứng của tài liệu'}.`,
        
        `Theo nội dung trong "${activeDocument.name}", câu hỏi của bạn liên quan đến phần chính của tài liệu. Tôi khuyên bạn nên chú ý đến các điểm sau: 1) Định nghĩa cơ bản, 2) Phương pháp áp dụng, 3) Ví dụ thực tế.`,
        
        `Tài liệu "${activeDocument.name}" có đề cập đến vấn đề này. Để hiểu rõ hơn, bạn có thể xem lại phần tóm tắt và ghi chú mà tôi đã tạo. Bạn có muốn tôi giải thích thêm về điểm nào cụ thể không?`,
        
        `Câu hỏi rất hay! Trong "${activeDocument.name}", chúng ta có thể tìm thấy thông tin liên quan. Tôi sẽ giúp bạn phân tích step-by-step để hiểu rõ hơn về vấn đề này.`
      ];

      const randomResponse = responses[Math.floor(Math.random() * responses.length)];

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: randomResponse,
        timestamp: new Date(),
        documentId: activeDocument.id
      };

      const finalMessages = [...newMessages, assistantMessage];
      saveChatMessages(finalMessages);

    } catch (error) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "Xin lỗi, có lỗi xảy ra. Vui lòng kiểm tra API key và thử lại.",
        timestamp: new Date(),
        documentId: activeDocument.id
      };
      saveChatMessages([...newMessages, errorMessage]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const deleteDocument = (id: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa tài liệu này?')) {
      const newDocs = documents.filter(doc => doc.id !== id);
      saveDocuments(newDocs);
      
      if (activeDocument?.id === id) {
        setActiveDocument(null);
      }

      // Remove related chat messages
      const newMessages = chatMessages.filter(msg => msg.documentId !== id);
      saveChatMessages(newMessages);
    }
  };

  const getDocumentIcon = (type: string) => {
    switch (type) {
      case 'pdf': return FileText;
      case 'video': return Video;
      case 'text': return BookOpen;
      default: return FileText;
    }
  };

  const getFilteredChatMessages = () => {
    return activeDocument 
      ? chatMessages.filter(msg => msg.documentId === activeDocument.id)
      : [];
  };

  const filteredMessages = getFilteredChatMessages();

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        <Button 
          onClick={onBack}
          variant="ghost" 
          className="mb-6 text-red-600 hover:text-red-700 hover:bg-red-50"
        >
          ← Quay lại
        </Button>

        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-red-600 mb-2">Giải Tài Liệu Cùng AI</h1>
          <p className="text-gray-600">Upload tài liệu và chat với AI để học tập hiệu quả</p>
        </div>



        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Documents List */}
          <div className="lg:col-span-1">
            <Card className="p-6 border-2 border-red-100 bg-white">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-red-600">Tài Liệu</h2>
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.mp4,.avi,.mov,.txt,.md"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <Button 
                    size="sm" 
                    className="bg-red-500 hover:bg-red-600 text-white"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="w-4 h-4 mr-1" />
                    Upload
                  </Button>
                </div>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto">
                {documents.length === 0 ? (
                  <div className="text-center py-8">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-500 text-sm">
                      Chưa có tài liệu nào
                    </p>
                  </div>
                ) : (
                  documents.map((doc) => {
                    const IconComponent = getDocumentIcon(doc.type);
                    return (
                      <div
                        key={doc.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          activeDocument?.id === doc.id
                            ? 'bg-red-50 border-red-300'
                            : 'bg-gray-50 border-gray-200 hover:border-red-200'
                        }`}
                        onClick={() => setActiveDocument(doc)}
                      >
                        <div className="flex items-start gap-3">
                          <IconComponent className="w-5 h-5 text-red-500 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm text-gray-800 truncate">
                              {doc.name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {doc.uploadDate.toLocaleDateString('vi-VN')}
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <div className={`text-xs px-2 py-0.5 rounded-full ${
                                doc.processed 
                                  ? 'bg-green-100 text-green-700' 
                                  : 'bg-yellow-100 text-yellow-700'
                              }`}>
                                {doc.processed ? 'Đã xử lý' : 'Chưa xử lý'}
                              </div>
                            </div>
                          </div>
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteDocument(doc.id);
                            }}
                            variant="ghost"
                            size="sm"
                            className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeDocument ? (
              <Card className="p-6 border-2 border-red-100 bg-white h-full">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-red-600 truncate">
                    {activeDocument.name}
                  </h2>
                  {!activeDocument.processed && (
                    <Button
                      onClick={() => processDocument(activeDocument)}
                      disabled={isProcessing}
                      size="sm"
                      className="bg-red-500 hover:bg-red-600 text-white"
                    >
                      {isProcessing ? 'Đang xử lý...' : 'Xử lý AI'}
                    </Button>
                  )}
                </div>

                <Tabs defaultValue="summary" className="h-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="summary">Tóm tắt</TabsTrigger>
                    <TabsTrigger value="notes">Ghi chú</TabsTrigger>
                    <TabsTrigger value="chat">Chat AI</TabsTrigger>
                  </TabsList>

                  <TabsContent value="summary" className="mt-4">
                    <div className="h-96 overflow-y-auto">
                      {activeDocument.processed ? (
                        <div className="prose max-w-none">
                          <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                            {activeDocument.summary}
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                          <FileText className="w-16 h-16 mb-4 opacity-50" />
                          <p>Tài liệu chưa được xử lý bởi AI</p>
                          <p className="text-sm">Nhấn "Xử lý AI" để tạo tóm tắt</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="notes" className="mt-4">
                    <div className="h-96 overflow-y-auto">
                      {activeDocument.processed ? (
                        <div className="prose max-w-none">
                          <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                            {activeDocument.notes}
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                          <BookOpen className="w-16 h-16 mb-4 opacity-50" />
                          <p>Chưa có ghi chú học tập</p>
                          <p className="text-sm">Nhấn "Xử lý AI" để tạo ghi chú</p>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="chat" className="mt-4">
                    <div className="flex flex-col h-96">
                      {/* Chat Messages */}
                      <div className="flex-1 overflow-y-auto mb-4 space-y-3">
                        {filteredMessages.length === 0 ? (
                          <div className="flex flex-col items-center justify-center h-full text-gray-500">
                            <MessageCircle className="w-16 h-16 mb-4 opacity-50" />
                            <p>Bắt đầu chat với tài liệu</p>
                            <p className="text-sm">Hỏi AI về nội dung tài liệu</p>
                          </div>
                        ) : (
                          filteredMessages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                            >
                              <div
                                className={`max-w-[80%] p-3 rounded-lg ${
                                  message.role === 'user'
                                    ? 'bg-red-500 text-white'
                                    : 'bg-gray-100 text-gray-800'
                                }`}
                              >
                                <p className="text-sm leading-relaxed">
                                  {message.content}
                                </p>
                                <p
                                  className={`text-xs mt-2 ${
                                    message.role === 'user' ? 'text-red-100' : 'text-gray-500'
                                  }`}
                                >
                                  {message.timestamp.toLocaleTimeString('vi-VN', {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </p>
                              </div>
                            </div>
                          ))
                        )}

                        {isChatLoading && (
                          <div className="flex justify-start">
                            <div className="bg-gray-100 rounded-lg p-3">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                              </div>
                            </div>
                          </div>
                        )}

                        <div ref={messagesEndRef} />
                      </div>

                      {/* Chat Input */}
                      <div className="flex gap-2">
                        <Input
                          value={inputMessage}
                          onChange={(e) => setInputMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                          placeholder="Hỏi AI về nội dung tài liệu..."
                          className="flex-1 border-red-200 focus:border-red-400"
                          disabled={isChatLoading || !activeDocument.processed}
                        />
                        <Button
                          onClick={sendMessage}
                          disabled={!inputMessage.trim() || isChatLoading || !activeDocument.processed}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </Card>
            ) : (
              <div className="flex flex-col items-center justify-center h-96 text-gray-500">
                <Upload className="w-20 h-20 mb-6 opacity-50" />
                <h3 className="text-xl font-medium mb-2">Chọn hoặc upload tài liệu</h3>
                <p className="text-center max-w-md">
                  Upload file PDF, video bài giảng hoặc ghi chú text để AI giúp bạn tóm tắt, 
                  tạo ghi chú và trả lời câu hỏi về nội dung.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}