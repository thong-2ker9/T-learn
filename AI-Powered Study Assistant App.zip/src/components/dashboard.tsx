import { 
  Brain, 
  MessageCircle, 
  Layers, 
  CheckSquare, 
  AlarmClock, 
  Calendar, 
  Shirt, 
  Upload, 
  Timer,
  Heart,
  User,
  Camera,
  Archive,
  StickyNote
} from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { useState, useRef } from "react";

interface DashboardProps {
  onFeatureSelect: (feature: string) => void;
}

const aiFeatures = [
  {
    id: "homework-solver",
    title: "AI Giải Bài Tập",
    description: "Giải mọi bài tập mọi lĩnh vực",
    icon: Brain,
    color: "bg-purple-500 hover:bg-purple-600"
  },
  {
    id: "chat-support",
    title: "AI Tâm Lý",
    description: "Hỗ trợ trò chuyện và tâm lý",
    icon: MessageCircle,
    color: "bg-green-500 hover:bg-green-600"
  },
  {
    id: "study-assistant",
    title: "Giải Tài Liệu Cùng AI",
    description: "Upload file và tương tác AI",
    icon: Upload,
    color: "bg-red-500 hover:bg-red-600"
  }
];

const supportTools = [
  {
    id: "flashcards",
    title: "Flashcard",
    description: "Tạo và ôn tập thẻ ghi nhớ",
    icon: Layers,
    color: "bg-blue-500 hover:bg-blue-600"
  },
  {
    id: "tasks",
    title: "Nhiệm vụ",
    description: "Quản lý học tập và thông báo",
    icon: CheckSquare,
    color: "bg-orange-500 hover:bg-orange-600"
  },
  {
    id: "alarm",
    title: "Báo thức",
    description: "Gọi dậy và bấm giờ",
    icon: AlarmClock,
    color: "bg-pink-500 hover:bg-pink-600"
  },
  {
    id: "schedule",
    title: "Thời khóa biểu",
    description: "Upload ảnh thời khóa biểu",
    icon: Calendar,
    color: "bg-yellow-500 hover:bg-yellow-600"
  },
  {
    id: "uniform",
    title: "Đồng phục",
    description: "Nhắc nhở mặc đồ theo ngày",
    icon: Shirt,
    color: "bg-indigo-500 hover:bg-indigo-600"
  },
  {
    id: "pomodoro",
    title: "Tập trung",
    description: "Pomodoro Timer",
    icon: Timer,
    color: "bg-red-500 hover:bg-red-600"
  },
  {
    id: "health",
    title: "Sức khỏe",
    description: "Nhắc nhở uống nước, tập thể dục, thiền",
    icon: Heart,
    color: "bg-green-500 hover:bg-green-600"
  },
  {
    id: "storage",
    title: "Lưu trữ",
    description: "Quản lý tài liệu học tập",
    icon: Archive,
    color: "bg-cyan-500 hover:bg-cyan-600"
  },
  {
    id: "notes",
    title: "Ghi chú",
    description: "Ghi chú nhanh phong cách iPhone",
    icon: StickyNote,
    color: "bg-amber-500 hover:bg-amber-600"
  }
];

export function Dashboard({ onFeatureSelect }: DashboardProps) {
  const [avatarImage, setAvatarImage] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setAvatarImage(result);
        localStorage.setItem('userAvatar', result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Load saved avatar and name on component mount
  useState(() => {
    const savedAvatar = localStorage.getItem('userAvatar');
    const savedName = localStorage.getItem('userName');
    if (savedAvatar) {
      setAvatarImage(savedAvatar);
    }
    if (savedName) {
      setUserName(savedName);
    }
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6 bg-gradient-to-r from-red-500 to-red-600 text-white p-6 rounded-3xl">
          <div className="flex items-center gap-4">
            <div 
              className="relative w-12 h-12 bg-white rounded-full flex items-center justify-center cursor-pointer group hover:bg-gray-100 transition-colors"
              onClick={handleAvatarClick}
            >
              {avatarImage ? (
                <img 
                  src={avatarImage} 
                  alt="Avatar" 
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <User className="w-6 h-6 text-red-500" />
              )}
              <div className="absolute inset-0 bg-black/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Camera className="w-4 h-4 text-white" />
              </div>
            </div>
            <div>
              <h2 className="text-lg font-semibold">Xin chào{userName ? ` ${userName}` : ""}!</h2>
              <p className="text-red-100 text-sm">Chào mừng đến với StudyAI</p>
            </div>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="hidden"
          />
        </div>



        {/* AI Features Section */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Tiện ích AI</h3>
          <div className="grid grid-cols-3 gap-4">
            {aiFeatures.map((feature) => {
              const IconComponent = feature.icon;
              return (
                <Card
                  key={feature.id}
                  className="p-4 cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg border-0 shadow-sm"
                  onClick={() => onFeatureSelect(feature.id)}
                >
                  <div className="text-center">
                    <div className={`w-12 h-12 rounded-2xl ${feature.color} flex items-center justify-center mx-auto mb-3 transition-colors duration-200 relative`}>
                      <IconComponent className="w-6 h-6 text-white" />
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">!</span>
                      </div>
                    </div>
                    <p className="text-sm font-medium text-gray-800">{feature.title}</p>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Support Tools Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Công cụ hỗ trợ</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {supportTools.map((tool) => {
              const IconComponent = tool.icon;
              return (
                <Card
                  key={tool.id}
                  className="p-4 cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg border-0 shadow-sm"
                  onClick={() => onFeatureSelect(tool.id)}
                >
                  <div className="text-center">
                    <div className={`w-12 h-12 rounded-2xl ${tool.color} flex items-center justify-center mx-auto mb-3 transition-colors duration-200`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-sm font-medium text-gray-800">{tool.title}</p>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>


      </div>
    </div>
  );
}