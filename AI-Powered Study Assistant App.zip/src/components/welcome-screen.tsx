import { BookOpen } from "lucide-react";
import { Button } from "./ui/button";

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-red-500 flex flex-col items-center justify-center px-6">
      <div className="flex flex-col items-center text-center">
        {/* Logo */}
        <div className="flex items-center gap-4 mb-8">
          <BookOpen className="w-16 h-16 text-white" />
          <h1 className="text-6xl font-bold text-white">T-Learn</h1>
        </div>
        
        {/* Welcome text */}
        <h2 className="text-2xl text-white mb-16 font-normal">
          Welcome to T-Learn
        </h2>
        
        {/* Get started button */}
        <Button 
          onClick={onGetStarted}
          className="bg-white text-red-500 hover:bg-gray-100 px-12 py-4 text-lg rounded-full shadow-lg transform transition-all duration-200 hover:scale-105"
        >
          Bắt đầu học ngay
        </Button>
      </div>
    </div>
  );
}