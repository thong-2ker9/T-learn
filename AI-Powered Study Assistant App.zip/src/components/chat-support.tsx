import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { MessageCircle, Send, User, Bot } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface ChatSupportProps {
  onBack: () => void;
}

export function ChatSupport({ onBack }: ChatSupportProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Xin chào! Tôi là trợ lý AI hỗ trợ tâm lý và học tập. Tôi có thể giúp bạn với:\n\n• Áp lực học tập\n• Stress trước kỳ thi\n• Động lực học tập\n• Quản lý thời gian\n• Tâm lý học đường\n• Các vấn đề khác liên quan đến học tập\n\nHãy chia sẻ với tôi những gì bạn đang lo lắng nhé!",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputMessage,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);

    try {
      // Mock API response - thay thế bằng API thực tế
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const responses = [
        "Tôi hiểu bạn đang cảm thấy áp lực. Điều này rất bình thường và nhiều học sinh cũng trải qua những cảm giác tương tự. Hãy thử áp dụng kỹ thuật thở sâu: hít vào trong 4 giây, giữ trong 4 giây, thở ra trong 6 giây. Bạn có muốn tôi chia sẻ thêm một số phương pháp giảm stress không?",

        "Thiếu động lực học tập là vấn đề rất phổ biến. Hãy thử đặt những mục tiêu nhỏ, có thể đạt được trong ngày và thưởng cho bản thân khi hoàn thành. Bạn có thể chia sẻ cụ thể hơn về tình huống của mình không?",

        "Việc quản lý thời gian hiệu quả rất quan trọng. Tôi khuyên bạn nên sử dụng kỹ thuật Pomodoro (25 phút tập trung + 5 phút nghỉ). Bạn có thể thử tính năng Pomodoro trong app này. Điều gì khiến bạn cảm thấy khó quản lý thời gian nhất?",

        "Cảm ơn bạn đã chia sẻ. Tôi sẽ lắng nghe và hỗ trợ bạn tốt nhất có thể. Hãy nhớ rằng mọi khó khăn đều có thể vượt qua được, và bạn không cần phải đối mặt với chúng một mình.",
      ];

      const randomResponse =
        responses[Math.floor(Math.random() * responses.length)];

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: randomResponse,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content:
          "Xin lỗi, có lỗi xảy ra. Vui lòng kiểm tra API key và thử lại.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("vi-VN", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white p-6">
      <div className="max-w-4xl mx-auto">
        <Button
          onClick={onBack}
          variant="ghost"
          className="mb-6 text-red-600 hover:text-red-700 hover:bg-red-50"
        >
          ← Quay lại
        </Button>

        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-red-600 mb-2">
            AI Hỗ Trợ Tâm Lý
          </h1>
          <p className="text-gray-600">
            Trò chuyện và giải quyết các vấn đề tâm lý học đường
          </p>
        </div>



        <Card className="h-[600px] border-2 border-red-100 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b bg-red-50 rounded-t-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-red-700">
                  Trợ Lý Tâm Lý AI
                </h3>
                <p className="text-sm text-red-500">
                  Luôn sẵn sàng lắng nghe và hỗ trợ bạn
                </p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] flex gap-3 ${
                    message.role === "user"
                      ? "flex-row-reverse"
                      : "flex-row"
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === "user"
                        ? "bg-red-500"
                        : "bg-red-100"
                    }`}
                  >
                    {message.role === "user" ? (
                      <User className="w-4 h-4 text-white" />
                    ) : (
                      <Bot className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                  <div
                    className={`rounded-2xl p-3 ${
                      message.role === "user"
                        ? "bg-red-500 text-white"
                        : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    <p className="whitespace-pre-wrap leading-relaxed">
                      {message.content}
                    </p>
                    <p
                      className={`text-xs mt-2 ${
                        message.role === "user"
                          ? "text-red-100"
                          : "text-gray-500"
                      }`}
                    >
                      {formatTime(message.timestamp)}
                    </p>
                  </div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="flex gap-3">
                  <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-red-500" />
                  </div>
                  <div className="bg-gray-100 rounded-2xl p-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t bg-white">
            <div className="flex gap-3">
              <Input
                value={inputMessage}
                onChange={(e) =>
                  setInputMessage(e.target.value)
                }
                onKeyPress={handleKeyPress}
                placeholder="Chia sẻ suy nghĩ, cảm xúc hoặc vấn đề của bạn..."
                className="flex-1 border-red-200 focus:border-red-400"
                disabled={isLoading}
              />
              <Button
                onClick={sendMessage}
                disabled={!inputMessage.trim() || isLoading}
                className="bg-red-500 hover:bg-red-600 text-white px-6"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}